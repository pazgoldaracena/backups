# Replace the "ANSWER HERE" for your answer

def max_of_two(x, y):
    """Given x and y, that are 2 numbers, return the biggest number."""
    if x > y:
        return x
    else:
        return y


def max_of_three(x, y, z):
    """Given x, y and z, that are 3 numbers, return the biggest number of the three."""
    if (z > x) and (z > y):
        return z 
    elif (y > x) and (y > z):
        return y
    else:
        return x


print(max_of_three(0, 0, 0))