def number_to_month(month):
    months = ['enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio', 'julio', 
              'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre']
    if month > 0 and month <= 12:
        match = months[month - 1]
        return match
    else:
        return "error"