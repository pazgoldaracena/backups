def math():
    a = 57
    b = 7
    print(a + b)
    print(a - b)
    print(a * b)
    print((a + b) / 2)
    print(a // b)
    print(a % b)
    print(a / b)

math()
