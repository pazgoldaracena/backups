def ada():
    first_name = "AdA"
    last_name = "LoVeLAce"
    print(f"{first_name.lower()} {last_name.lower()}")
    print(f"{first_name.title()} {last_name.title()}")
    print(f"{first_name.upper()} {last_name.upper()}")
    print(f"\t{first_name.lower()} {last_name.lower()}")