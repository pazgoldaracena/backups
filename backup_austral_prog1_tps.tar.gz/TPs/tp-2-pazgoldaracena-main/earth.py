def earth():
    x = "Bangladesh"
    y = "Barbados"
    print(f"The result of {x} comes first in the dictionary than {y} is {x < y}.")
    print(f"The result of {y} comes first in the dictionary than {x} is {x > y}.")