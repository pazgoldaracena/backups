def list_of_lists(list_of_lists_to_modify):
    if list_of_lists_to_modify[0]:
        item1 = list_of_lists_to_modify[0][0]
        if len(list_of_lists_to_modify[0]) >= 2:
            item2 = list_of_lists_to_modify[0][1]
            new_lst1 = [item1, item2]
        else:
            new_lst1 = [item1]
        list_of_lists_to_modify[0] = new_lst1

    if len(list_of_lists_to_modify[1]) >= 2:
        items_lst2 = list_of_lists_to_modify[1][1:4]
        list_of_lists_to_modify[1] = items_lst2
    else:
        list_of_lists_to_modify[1] = []

    if len(list_of_lists_to_modify[1]) >= 2:
        list_of_lists_to_modify[2].reverse()
        items_list3 = list_of_lists_to_modify[2][0:2]
        list_of_lists_to_modify[2] = items_list3
        items_list3.reverse()


    return list_of_lists_to_modify


lst_of_lsts = [[1, 2, 3], [4, 5, 6, 7, 8], [9, 10, 11, 12]]
# output1: [[1, 2], [5, 6, 7], [11, 12]]
print(list_of_lists(lst_of_lsts))

lst_of_lsts2 = [[], [4, 5, 6], [10, 11, 12]]
# output2: [[], [5, 6], [11, 12]]
print(list_of_lists(lst_of_lsts2))

lst_of_lsts3 = [[1, 2], [], [12]]
# expected3 = [[1, 2], [], [12]]
print(list_of_lists(lst_of_lsts3))

lst_of_lsts4 = [[1], [4], []]
print(list_of_lists(lst_of_lsts4))
# expected4 = [[1], [], []]