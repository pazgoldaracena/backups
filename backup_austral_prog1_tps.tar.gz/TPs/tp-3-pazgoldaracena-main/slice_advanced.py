def slice_advanced():
    # Código a implementar utilizando input.
    txt = input(" ")
    print(txt[4::2])
slice_advanced()

# Para verificar este ejercicio ejecutar el comando
# `pytest tp3_slice_advanced_test.py` o `python tp3_slice_advanced_test.py`